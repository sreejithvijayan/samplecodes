﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.IO;
using System.Data.OleDb;

namespace FileReadSampleActivityLibrary
{

    public sealed class CustomCodeActivity : CodeActivity
    {
        // Define an activity input argument of type string
        public InArgument<string> Text { get; set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            string con =
                        @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\File_Upload_13May_NoSheetName_Invalid.xlsx;" +
                        @"Extended Properties='Excel 8.0;HDR=Yes;'";
            bool isFileInvalid = false;
            using (OleDbConnection connection = new OleDbConnection(con))
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("select * from [Sheet1$]", connection);
                using (OleDbDataReader dr = command.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        var row1Col0 = dr["PO Number"];
                        if (row1Col0 != null && row1Col0.ToString().StartsWith("PO"))
                        {                           
                        }
                        else
                        {
                            isFileInvalid = true;                            
                            break;
                        }
                    }
                    if(isFileInvalid)
                    {
                        Console.WriteLine("File is Invalid");
                    }
                    else
                    {
                        Console.WriteLine("File is valid");
                    }
                }
            }
              
            
            
        }
    }
}
