﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using FileReadSampleActivityLibrary;

namespace WFTestApp
{

    class Program
    {
        static void Main(string[] args)
        {
            CustomCodeActivity workflow1 = new CustomCodeActivity();
            WorkflowInvoker.Invoke(workflow1);           
        }
    }
}
